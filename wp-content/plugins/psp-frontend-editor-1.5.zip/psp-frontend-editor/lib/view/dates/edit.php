<input type="text" class="psp-datepicker" value="" data-date_type="">
