<?php
/**
 * Heading email template.
 *
 * @since {{VERSION}}
 *
 * @var string $recipient_name The name of the email recipient.
 */

defined( 'ABSPATH' ) || die(); ?>
