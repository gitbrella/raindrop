<?php include( psp_template_hierarchy( 'dashboard/header' ) ); ?>

<div id="psp-archive-container" class="psp-grid-container-fluid">

    <?php include( psp_template_hierarchy( 'global/login.php' ) ); ?>

</div>

<?php include( psp_template_hierarchy( 'dashboard/footer' ) ); ?>
